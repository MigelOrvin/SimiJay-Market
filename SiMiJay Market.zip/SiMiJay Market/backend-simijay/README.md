## Fitur :
<ul>
  <li>Auth</li>
  <li>Manajemen User</li>
  <li>Barang</li>
  <li>Supplier</li>
  <li>Kategori</li>
  <li>Satuan</li>
  <li>Role admin dan suppler</li>
  <li>Role admin dan suppler</li>
</ul>

## Ini adalah bagian backendnya
## Frontend menggunakan ReactJS
### Repositori Frontend : [https://github.com/fadhilahhfdz/react-microservices-frontend.git](https://github.com/fadhilahhfdz/react-microservices-frontend.git)
