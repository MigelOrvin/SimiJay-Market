## Fitur :
<ul>
  <li>Auth</li>
  <li>Manajemen User</li>
  <li>Barang</li>
  <li>Supplier</li>
  <li>Kategori</li>
  <li>Satuan</li>
  <li>Role admin dan suppler</li>
  <li>Role admin dan suppler</li>
</ul>

## Ini adalah bagian frontendnya
## Backend menggunakan laravel 10
### Repositori Backend : [https://github.com/fadhilahhfdz/laravel10-microservice-backend.git](https://github.com/fadhilahhfdz/laravel10-microservice-backend.git)
