import React from 'react';

const Laporan = () => {
  return (
    <div>
      <h1>Transaksi Page</h1>
    </div>
  );
};

export default Laporan;
