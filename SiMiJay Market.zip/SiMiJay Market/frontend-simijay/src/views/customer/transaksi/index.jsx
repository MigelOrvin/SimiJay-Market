import React from 'react';

const Transaksi = () => {
  return (
	<div>
	  <h1>Transaksi Page</h1>
	</div>
  );
};

export default Transaksi;
